## part 1 ##
run #gpdb
choose a gpv5 cluster
make sure the cluster is healthy: # gpstate -e
run the script of part1: # bash 1st_part_double_fault.sh 

## part 2 ##
run # gpdb
choose a gpv6 cluster
make sure the cluster is healthy: # gpstate -e
run the script in part2 folder one by one. follow the doc: https://docs.google.com/spreadsheets/d/1S6O-wyG3MXKBd0xMFCAGzVg_fRASfFywuJUV7Cc8yC4/edit#gid=0

update the doc once you finished each task.
